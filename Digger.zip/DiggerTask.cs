﻿using System;
using Avalonia.Input;

namespace Digger;

//Напишите здесь классы Player, Terrain и другие.